//----------------------------------------------------------------------------------------------+
//               PIN MAP for  Arduino Pro-Mini - Each I/O pin used is defined . . .
//----------------------------------------------------------------------------------------------+
// PWM pins are: 3, 5, 6, 9, 10, and 11. (tone interfears with PWM on D3 & D11)
// NOTE: A6 & A7 are analog in pins ONLY
#define HV_POT            A6             // HV adjustment pot (analog only)
#define LED_PIN           13             // 1mS flash / event - also flashes 5X at startup
#define PWM_PIN            9             // Timer1 PWM pin - ATmega328: 9&10 / Atmage1284: 12&13


#if (NANO) // redefine all I/O pins 
#define HV_POT            A6             // HV adjustment pot (analog only)
#define PWM_PIN            9             // Timer1 PWM pin - ATmega328: 9&10 / Atmage1284: 12&13
#endif

#define HV_MIN_PWM           51         // minimum PWM duty - 51/1023 = 5%
#define HV_MAX_PWM           819        // maximum PWM duty - 819/1023 = 80% (HV lower after 80%)
#define POT_HYSTERESIS       4          // amount of change in potentiometer value needed to trigger a recalculation of HV (keeps the value from bouncing around)



