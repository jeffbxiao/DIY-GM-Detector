package com.example.jeffery.diy_map;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;


import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback, PopupMenu.OnMenuItemClickListener {
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();
        mMap = googleMap;
        if (mLocationPermissionGranted) {
            getDeviceLocation();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
        }
    }

    private static final String TAG = "MapActivity";
    private EditText mEditText;
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private Boolean mLocationPermissionGranted = false;
    private Boolean mSavePermissionGranted = false;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM=20f;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private HeatmapTileProvider mProvider;
    private int heatMapped = 0;
    private ArrayList<String> detectorData = new ArrayList<String>();
    private EditText mEmail;
    private EditText mName;

    //Create the buttons and run the basic steps, like asking for permission and creating the map
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        getLocationPermission();


        //Create a marker
        Button btnMark = (Button) findViewById(R.id.btnMark);
        btnMark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switcher();
                mEditText.setText("");
            }
        });

        //Cancel Marker
        Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);
        btnCancelMarker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout layout = (LinearLayout) findViewById(R.id.laid_out);
                layout.setVisibility(View.GONE);
                Button btnMark = (Button) findViewById(R.id.btnMark);
                btnMark.setVisibility(View.VISIBLE);
                Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);
                btnCancelMarker.setVisibility(View.GONE);
            }
        });

        //Set the marker value
        Button btnSet = (Button) findViewById(R.id.set);
        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeMarker();
                switch_back();
            }
        });

        //Clear all the markers
        Button btnClear = (Button) findViewById(R.id.btnClear);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.clear();
                Button btnClear = (Button) findViewById(R.id.btnClear);
                btnClear.setVisibility(View.GONE);
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.GONE);
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.GONE);
                markers.clear();
                coordinates.clear();
                detectorData.clear();

                if (heatMapped==1){
                    mOverlay.remove();
                    heatMapped= 0;
                }
            }
        });

        //add the heat map
        Button btnHeatMap = (Button) findViewById(R.id.btnHeatmap);
        btnHeatMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.GONE);
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.VISIBLE);
                for (Marker mkr:markers){
                    mkr.setVisible(false);
                }
                addHeatMap();
                heatMapped=1;
            }
        });

        //Remove the heat map
        Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
        btnHeatRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.GONE);
                mOverlay.remove();
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.VISIBLE);
                for (Marker mkr:markers){
                    mkr.setVisible(true);
                }
                heatMapped=0;
            }
        });

        //Press Export Data Button
        Button btnExportData = (Button) findViewById(R.id.btnExport);
        btnExportData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopup(v);
            }
        });

        //Cancel Email
        Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
        btnCancelEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);

            }
        });

        //Press Send
        Button btnSend = (Button) findViewById(R.id.btnSend);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
                sendEmail();

            }
        });

        //Cancel Text Save
        Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
        btnCancelText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getTextName = (LinearLayout) findViewById(R.id.getTextName);
                getTextName.setVisibility(View.GONE);
                Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                btnCancelText.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
            }
        });

        //Press Save
        Button btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getTextName = (LinearLayout) findViewById(R.id.getTextName);
                getTextName.setVisibility(View.GONE);
                Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                btnCancelText.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
                saveTextFile();
            }
        });

    }

    //Get the phone's exact location using google maps and move camera
    private void getDeviceLocation(){
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        try{
            if (mLocationPermissionGranted){
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()){
                            Location currentLocation=(Location) task.getResult();
                            moveCamera(new LatLng(currentLocation.getLatitude(),
                                            currentLocation.getLongitude()), DEFAULT_ZOOM);
                        }
                        else{
                            Toast.makeText(MapActivity.this,
                                    "Unable to get Current Location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } catch (SecurityException e){
        }
    }
    //move the map camera to the phone's location
    private void moveCamera(LatLng latLng, float zoom){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    //Initialize the map
    private void initMap(){
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(MapActivity.this);
    }

    //Ask for permission to use the phone's location
    private void getLocationPermission(){
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                mLocationPermissionGranted = true;
                initMap();
            }
            else{
                ActivityCompat.requestPermissions(this,
                        permissions, LOCATION_PERMISSION_REQUEST_CODE);
            }
        }
        else{
            ActivityCompat.requestPermissions(this,
                    permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }

    }

    //Response to location permission request. No map if denied
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        mSavePermissionGranted = false;

        switch (requestCode){
            case 1000:{
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                        mSavePermissionGranted = true;
                }else{
                    Toast.makeText(this,"Permission Denied", Toast.LENGTH_SHORT);
                }
            }
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length>0){
                    for (int i=0;i<grantResults.length; i++){
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            mLocationPermissionGranted = false;
                            return;
                        }
                    }
                    mLocationPermissionGranted = true;

                    //initialize the map
                    initMap();
                }
            }
        }
    }

    //Change buttons when the "Mark" button is pushed
    private void switcher(){
        //Take in text input and make the textbox visible
        LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
        getEmail.setVisibility(View.GONE);
        LinearLayout layout = (LinearLayout) findViewById(R.id.laid_out);
        layout.setVisibility(View.VISIBLE);
        Button btnMark = (Button) findViewById(R.id.btnMark);
        btnMark.setVisibility(View.GONE);
        Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);
        btnCancelMarker.setVisibility(View.VISIBLE);

        Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
        Button btnExport = (Button) findViewById(R.id.btnExport);
        if (btnCancelEmail.getVisibility()==View.VISIBLE){
            btnCancelEmail.setVisibility(View.GONE);
            btnExport.setVisibility(View.VISIBLE);
        }

        mEditText = (EditText) findViewById(R.id.edit_text);
        mEditText.getText().clear();

    }

    //Change buttons when the "Set" button is pushed
    private void switch_back(){
        //Take in text input and make the textbox visible
        LinearLayout layout = (LinearLayout) findViewById(R.id.laid_out);
        layout.setVisibility(View.GONE);
        Button btnClear = (Button) findViewById(R.id.btnClear);
        btnClear.setVisibility(View.VISIBLE);

        Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
        Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
        if (btnHeatRemove.getVisibility()==View.GONE){
            btnHeat.setVisibility(View.VISIBLE);
        }


        Button btnExport = (Button) findViewById(R.id.btnExport);
        btnExport.setVisibility(View.VISIBLE);
        Button btnMark = (Button) findViewById(R.id.btnMark);
        btnMark.setVisibility(View.VISIBLE);
        Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);
        btnCancelMarker.setVisibility(View.GONE);
    }




    //Find latitude, longitude and ask for count rate for the maker
    private void placeMarker(){
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        try{
            if (mLocationPermissionGranted){
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()){
                            Location currentLocation=(Location) task.getResult();

                            EditText mEditText = (EditText) findViewById(R.id.edit_text);
                            String counts = mEditText.getText().toString();


                            if (TextUtils.isDigitsOnly(counts) && counts != "" && counts != "0"&& !TextUtils.isEmpty(counts)){
                                setMarker(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()),
                                        DEFAULT_ZOOM, counts);
                            }
                            else {
                                Toast.makeText(MapActivity.this, "Please enter a number "
                                        + "greater than 0", Toast.LENGTH_SHORT).show();
                                Button btnClear = (Button) findViewById(R.id.btnClear);
                                btnClear.setVisibility(View.GONE);
                                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                                btnHeatRemove.setVisibility(View.GONE);
                                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                                btnHeat.setVisibility(View.GONE);
                                Button btnExport = (Button) findViewById(R.id.btnExport);
                                btnExport.setVisibility(View.GONE);
                                Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);
                                btnCancelMarker.setVisibility(View.GONE);
                                Button btnMark = (Button) findViewById(R.id.btnMark);
                                btnMark.setVisibility(View.VISIBLE);
                                return;
                            }
                        }
                        else{
                            Toast.makeText(MapActivity.this,
                                    "Unable to get Current Location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } catch (SecurityException e){
        }
    }

    //Create list for the markers to keep track of them
    private List<WeightedLatLng> coordinates = new ArrayList<WeightedLatLng>();
    private List<Marker> markers = new ArrayList<Marker>();
    //Place the marker using the information from "placeMarker" above
    private void setMarker(LatLng latLng, float zoom, String data){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
        double intensity = Double.parseDouble(data);

        detectorData.add("\nLat: "+latLng.latitude+", Long: "+latLng.longitude+", counts: "+data);

        MarkerOptions options = new MarkerOptions().position(latLng)
                .title("Lat: "+latLng.latitude+", Long: "+latLng.longitude).snippet(data);

        Marker m = mMap.addMarker(options);

        //Track all markers and input values
        WeightedLatLng location = new WeightedLatLng(latLng, intensity);
        markers.add(m);
        coordinates.add(location);

        //If heatmap is on, add invisible markers, update the heatmap with new weighted coordinates
        if (heatMapped==1){
            for (Marker mkr:markers){
                mkr.setVisible(false);
            }

            mOverlay.remove();
            addHeatMap();
        }
    }

    //Tile overlay for the heat map
    TileOverlay mOverlay;
    private void addHeatMap(){
        //Color Gradient (UNUSED)
        int[] gradientColors = {
                Color.rgb(0,255,0),
                Color.rgb(51,204,0),
                Color.rgb(102,153,0),
                Color.rgb(153,102,0),
                Color.rgb(204,51,0),
                Color.rgb(255,0,0),
        };

        float[] gradientBegins= {
                0.0f, 0.20f, 0.30f, 0.80f, 0.9f,1.0f
        };
        Gradient gradient = new Gradient(gradientColors, gradientBegins);

        //Create the heat map
        mProvider = new HeatmapTileProvider.Builder().weightedData(coordinates).gradient(gradient).radius(30).build();
        mOverlay = mMap.addTileOverlay(new TileOverlayOptions()
                .tileProvider(mProvider));
    }

    private void sendEmail(){

        EditText mEmail = findViewById(R.id.enter_email);
        String emailAddress = mEmail.getText().toString();
        if (emailAddress!=""){
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{mEmail.getText().toString()});
            intent.putExtra(Intent.EXTRA_SUBJECT, "DIY GM Data");
            intent.putExtra(Intent.EXTRA_TEXT, "Data: \n"+detectorData);

            try{
                startActivity(Intent.createChooser(intent, "Send Mail"));
            }
            catch (android.content.ActivityNotFoundException ex){
                Toast.makeText(MapActivity.this, "There is no email client installed",
                        Toast.LENGTH_SHORT);
            }

        }
        else{
            Toast.makeText(MapActivity.this, "Please enter a valid email address",
                    Toast.LENGTH_SHORT);
        }
    }

    //Save Text File
    public void saveTextFile() {
        EditText mName = findViewById(R.id.enter_name);
        String sFileName = mName.getText().toString()+".txt";
        String sBody = "Data: \n"+detectorData;
        if (sFileName!=""){
            File root = new File(Environment.getExternalStorageDirectory()
                    .getAbsolutePath(), sFileName);
            try {
                FileOutputStream fos = new FileOutputStream(root);
                fos.write(sBody.getBytes());
                fos.close();

                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(this, "File Not Found", Toast.LENGTH_SHORT).show();
            }catch (IOException e){
                e.printStackTrace();
                Toast.makeText(this, "Error Saving File", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Please Enter a File Name", Toast.LENGTH_SHORT).show();
        }

    }




    //export popup menu
    public void showPopup(View v){
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.export_menu);
        popupMenu.show();
    }


    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch(item.getItemId()){
            case R.id.exportEmail:
                LinearLayout layout = (LinearLayout) findViewById(R.id.laid_out);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                Button btnMark = (Button) findViewById(R.id.btnMark);
                Button btnCancelMarker = (Button) findViewById(R.id.btnCancelMark);

                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.VISIBLE);
                layout.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.VISIBLE);
                btnExport.setVisibility(View.GONE);
                btnMark.setVisibility(View.VISIBLE);
                btnCancelMarker.setVisibility(View.GONE);

                mEmail = (EditText) findViewById(R.id.enter_email);
                mEmail.getText().clear();
                return true;
            case R.id.exportText:
                //Get permission to save
                if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        !=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1000);
                }
                else{
                    mSavePermissionGranted=true;
                }

                if (mSavePermissionGranted==true) {
                    //some reason it didn't like it unless I redid these with different names
                    LinearLayout layout2 = (LinearLayout) findViewById(R.id.laid_out);
                    Button btnExport2 = (Button) findViewById(R.id.btnExport);
                    Button btnMark2 = (Button) findViewById(R.id.btnMark);
                    Button btnCancelMarker2 = (Button) findViewById(R.id.btnCancelMark);

                    LinearLayout getText = (LinearLayout) findViewById(R.id.getTextName);
                    getText.setVisibility(View.VISIBLE);
                    layout2.setVisibility(View.GONE);
                    Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                    btnCancelText.setVisibility(View.VISIBLE);
                    btnExport2.setVisibility(View.GONE);
                    btnMark2.setVisibility(View.VISIBLE);
                    btnCancelMarker2.setVisibility(View.GONE);
                    mName = (EditText) findViewById(R.id.enter_name);
                    mName.getText().clear();
                    return true;
                }else{
                    return true;
                }
            default:
                return false;
        }
    }
}
