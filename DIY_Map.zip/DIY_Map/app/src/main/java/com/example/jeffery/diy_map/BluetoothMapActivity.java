package com.example.jeffery.diy_map;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.heatmaps.Gradient;
import com.google.maps.android.heatmaps.HeatmapTileProvider;
import com.google.maps.android.heatmaps.WeightedLatLng;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;


public class BluetoothMapActivity extends AppCompatActivity implements OnMapReadyCallback, PopupMenu.OnMenuItemClickListener {
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();
        mMap = googleMap;
        if (mLocationPermissionGranted) {
            getDeviceLocation();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
        }
    }

    private static final String TAG = "BluetoothMapActivity";
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private Boolean mLocationPermissionGranted = false;
    private Boolean mSavePermissionGranted = false;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM=20f;
    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private HeatmapTileProvider mProvider;
    private int heatMapped = 0;
    private ArrayList<String> detectorData = new ArrayList<String>();
    private String text;
    private String holder1 = null;
    private EditText mEmail;
    private EditText mName;
    TextView incomingMesages;
    TextView automated_display;
    StringBuilder messages;
    Boolean timeCountRequest=false;
    int totalCounts;
    int y = 0;

    //Create the buttons and run the basic steps, like asking for permission and creating the map
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_map);

        getLocationPermission();

        incomingMesages = (TextView) findViewById(R.id.incomingMessages);
        automated_display = (TextView) findViewById(R.id.automated_display);
        messages = new StringBuilder();
        LocalBroadcastManager.getInstance(BluetoothMapActivity.this).registerReceiver(mReceiver,
                new IntentFilter("incomingMessage"));
        LocalBroadcastManager.getInstance(BluetoothMapActivity.this).registerReceiver(mTimedCollection,
                new IntentFilter("incomingMessage"));

        //Enable timed interval collection
        Button btnTimed = (Button) findViewById(R.id.btnTimed);
        btnTimed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnDisableTimed = (Button) findViewById(R.id.btnDisableTimed);
                Button btnTimed = (Button) findViewById(R.id.btnTimed);
                btnTimed.setVisibility(View.GONE);
                btnDisableTimed.setVisibility(View.VISIBLE);
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);

                TextView countRate = (TextView) findViewById(R.id.Count_Rate);
                TextView incomingMessages = (TextView) findViewById(R.id.incomingMessages);
                countRate.setVisibility(View.GONE);
                incomingMessages.setVisibility(View.GONE);

                LinearLayout setTime = (LinearLayout) findViewById(R.id.setTime);
                setTime.setVisibility(View.VISIBLE);
                EditText enterTime = (EditText) findViewById(R.id.enter_time);
                enterTime.getText().clear();
            }
        });

        //Set Time button
        Button btnSet = (Button) findViewById(R.id.btnSet);
        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnMark = (Button) findViewById(R.id.btnMark);
                btnMark.setVisibility(View.GONE);
                LinearLayout setTime = (LinearLayout) findViewById(R.id.setTime);
                setTime.setVisibility(View.GONE);
                timed();

                TextView Total_Counts = (TextView) findViewById(R.id.Total_Counts);
                TextView automated_display = (TextView) findViewById(R.id.automated_display);
                Total_Counts.setVisibility(View.VISIBLE);
                automated_display.setVisibility(View.VISIBLE);
            }
        });

        //Disable timed interval collection
        Button btnDisableTimed = (Button) findViewById(R.id.btnDisableTimed);
        btnDisableTimed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView countRate = (TextView) findViewById(R.id.Count_Rate);
                TextView incomingMessages = (TextView) findViewById(R.id.incomingMessages);
                countRate.setVisibility(View.VISIBLE);
                incomingMessages.setVisibility(View.VISIBLE);

                Button btnDisableTimed = (Button) findViewById(R.id.btnDisableTimed);
                Button btnTimed = (Button) findViewById(R.id.btnTimed);
                btnTimed.setVisibility(View.VISIBLE);
                btnDisableTimed.setVisibility(View.GONE);
                Button btnMark = (Button) findViewById(R.id.btnMark);
                btnMark.setVisibility(View.VISIBLE);
                LinearLayout setTime = (LinearLayout) findViewById(R.id.setTime);
                setTime.setVisibility(View.GONE);

                TextView Total_Counts = (TextView) findViewById(R.id.Total_Counts);
                TextView automated_display = (TextView) findViewById(R.id.automated_display);
                Total_Counts.setVisibility(View.GONE);
                automated_display.setVisibility(View.GONE);

                timeCountRequest=false;
            }
        });

        //Create a marker
        Button btnMark = (Button) findViewById(R.id.btnMark);
        btnMark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeMarker(text);
                switch_back();

            }
        });

        //Clear all the markers
        Button btnClear = (Button) findViewById(R.id.btnClear);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.clear();
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                Button btnClear = (Button) findViewById(R.id.btnClear);
                btnClear.setVisibility(View.GONE);
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.GONE);
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.GONE);
                markers.clear();
                coordinates.clear();
                detectorData.clear();

                if (heatMapped==1){
                    mOverlay.remove();
                    heatMapped= 0;
                }
            }
        });

        //add the heat map
        Button btnHeatMap = (Button) findViewById(R.id.btnHeatmap);
        btnHeatMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.GONE);
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.VISIBLE);
                for (Marker mkr:markers){
                    mkr.setVisible(false);
                }
                addHeatMap();
                heatMapped=1;
            }
        });

        //Remove the heat map
        Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
        btnHeatRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnHeatRemove = (Button) findViewById(R.id.btnHeatRemove);
                btnHeatRemove.setVisibility(View.GONE);
                mOverlay.remove();
                Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
                btnHeat.setVisibility(View.VISIBLE);
                for (Marker mkr:markers){
                    mkr.setVisible(true);
                }
                heatMapped=0;
            }
        });

        //Press Export Data Button
        Button btnExportData = (Button) findViewById(R.id.btnExport);
        btnExportData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopup(v);
            }
        });

        Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
        btnCancelEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
            }
        });

        //Press Send
        Button btnSend = (Button) findViewById(R.id.btnSend);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.GONE);
                sendEmail();
            }
        });

        //Cancel Text Save
        Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
        btnCancelText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getTextName = (LinearLayout) findViewById(R.id.getTextName);
                getTextName.setVisibility(View.GONE);
                Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                btnCancelText.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
            }
        });

        //Press Save
        Button btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout getTextName = (LinearLayout) findViewById(R.id.getTextName);
                getTextName.setVisibility(View.GONE);
                Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                btnCancelText.setVisibility(View.GONE);
                Button btnExport = (Button) findViewById(R.id.btnExport);
                btnExport.setVisibility(View.VISIBLE);
                saveTextFile();
            }
        });
    }

    //Timed Data Collection
    private int seconds;
    private void timed() {
        EditText enterTime = (EditText) findViewById(R.id.enter_time);
        String enteredTime = enterTime.getText().toString();
        seconds = Integer.parseInt(enteredTime);
        if (TextUtils.isDigitsOnly(enteredTime) && enteredTime != "" && enteredTime != "0"&&
                !TextUtils.isEmpty(enteredTime)){
            automated_display.setText("");
            timeCountRequest=true;
            y=0;
            totalCounts = 0;
            Toast.makeText(BluetoothMapActivity.this, "Beginning Timed Marking",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(BluetoothMapActivity.this, "Please enter a whole number "
                    + "greater than 0", Toast.LENGTH_SHORT).show();
            TextView countRate = (TextView) findViewById(R.id.Count_Rate);
            TextView incomingMessages = (TextView) findViewById(R.id.incomingMessages);
            countRate.setVisibility(View.VISIBLE);
            incomingMessages.setVisibility(View.VISIBLE);
            Button btnDisableTimed = (Button) findViewById(R.id.btnDisableTimed);
            Button btnTimed = (Button) findViewById(R.id.btnTimed);
            btnTimed.setVisibility(View.VISIBLE);
            btnDisableTimed.setVisibility(View.GONE);
            Button btnMark = (Button) findViewById(R.id.btnMark);
            btnMark.setVisibility(View.VISIBLE);
        }

    }

    //Receiver for the timed count request
    private String counting;
    BroadcastReceiver mTimedCollection = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            messages.setLength(0);
            counting = intent.getStringExtra("theMessage");
            int holding = Integer.parseInt(counting);
            totalCounts = totalCounts + holding;
            y = y+1;
            if (y==seconds && timeCountRequest==true){
                y=0;
                Button btnClear = (Button) findViewById(R.id.btnClear);
                if (btnClear.getVisibility()==View.GONE){
                    switch_back();
                }
                String number = Integer.toString(totalCounts);
                placeMarker(number);
                automated_display.setText(number);
                totalCounts = 0;
            }
        }
    };

    //Textbox Data Stream update
    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            messages.setLength(0);
            text = intent.getStringExtra("theMessage");
            holder1 = text;
            messages.append(holder1);
            incomingMesages.setText(messages);
        }
    };

    //Get the phone's exact location using google maps and move camera
    private void getDeviceLocation(){
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        try{
            if (mLocationPermissionGranted){
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()){
                            Location currentLocation=(Location) task.getResult();
                            moveCamera(new LatLng(currentLocation.getLatitude(),
                                            currentLocation.getLongitude()), DEFAULT_ZOOM);
                        }
                        else{
                            Toast.makeText(BluetoothMapActivity.this,
                                    "Unable to get Current Location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } catch (SecurityException e){
        }
    }
    //move the map camera to the phone's location
    private void moveCamera(LatLng latLng, float zoom){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    //Initialize the map
    private void initMap(){
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.activity_bluetooth_map);

        mapFragment.getMapAsync(BluetoothMapActivity.this);
    }

    //Ask for permission to use the phone's location
    private void getLocationPermission(){
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                mLocationPermissionGranted = true;
                initMap();
            }
            else{
                ActivityCompat.requestPermissions(this,
                        permissions, LOCATION_PERMISSION_REQUEST_CODE);
            }
        }
        else{
            ActivityCompat.requestPermissions(this,
                    permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }

    }

    //Change buttons when the "Set" button is pushed
    private void switch_back(){
        //Take in text input and make the textbox visible
        Button btnClear = (Button) findViewById(R.id.btnClear);
        btnClear.setVisibility(View.VISIBLE);
        Button btnHeat = (Button) findViewById(R.id.btnHeatmap);
        btnHeat.setVisibility(View.VISIBLE);
        Button btnExport = (Button) findViewById(R.id.btnExport);
        btnExport.setVisibility(View.VISIBLE);
    }

    //Response to location permission request. No map if denied
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        mLocationPermissionGranted = false;
        mSavePermissionGranted = false;
        switch (requestCode){
            case 1000:{
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    mSavePermissionGranted = true;
                }else{
                    Toast.makeText(this,"Permission Denied", Toast.LENGTH_SHORT);
                }
            }
            case LOCATION_PERMISSION_REQUEST_CODE:{
                if(grantResults.length>0){
                    for (int i=0;i<grantResults.length; i++){
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED){
                            mLocationPermissionGranted = false;
                            return;
                        }
                    }
                    mLocationPermissionGranted = true;

                    //initialize the map
                    initMap();
                }
            }
        }
    }

    //Find latitude, longitude and place the marker with the count rate
    private void placeMarker(final String text){
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        try{
            if (mLocationPermissionGranted){
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()){
                            Location currentLocation=(Location) task.getResult();

                            String counts = text;
                            setMarker(new LatLng(currentLocation.getLatitude(),
                                            currentLocation.getLongitude()), DEFAULT_ZOOM, counts);
                        }
                        else{
                            Toast.makeText(BluetoothMapActivity.this,
                                    "Unable to get Current Location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } catch (SecurityException e){
        }
    }

    //Create list for the markers to keep track of them
    private List<WeightedLatLng> coordinates = new ArrayList<WeightedLatLng>();
    private List<Marker> markers = new ArrayList<Marker>();
    //Place the marker using the information from "placeMarker" above
    private void setMarker(LatLng latLng, float zoom, String data){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
        double intensity = Double.parseDouble(data);

        detectorData.add("\nLat: "+latLng.latitude+", Long: "+latLng.longitude+", counts: "+data);

        MarkerOptions options = new MarkerOptions().position(latLng)
                .title("Lat: "+latLng.latitude+", Long: "+latLng.longitude).snippet(data);

        Marker m = mMap.addMarker(options);

        //Track all markers and input values
        WeightedLatLng location = new WeightedLatLng(latLng, intensity);
        markers.add(m);
        coordinates.add(location);

        //If heatmap is on, add invisible markers, update the heatmap with new weighted coordinates
        if (heatMapped==1){
            for (Marker mkr:markers){
                mkr.setVisible(false);
            }

            mOverlay.remove();
            addHeatMap();
        }
    }



    //Tile overlay for the heat map
    TileOverlay mOverlay;
    private void addHeatMap(){
        //Color Gradient (UNUSED)
        int[] gradientColors = {
                Color.rgb(0,255,0),
                Color.rgb(51,204,0),
                Color.rgb(102,153,0),
                Color.rgb(153,102,0),
                Color.rgb(204,51,0),
                Color.rgb(255,0,0),
        };

        float[] gradientBegins= {
                0.0f, 0.20f, 0.30f, 0.80f, 0.9f,1.0f
        };
        Gradient gradient = new Gradient(gradientColors, gradientBegins);
        mProvider = new HeatmapTileProvider.Builder().weightedData(coordinates).radius(30).gradient(gradient).build();
        mOverlay = mMap.addTileOverlay(new TileOverlayOptions()
                .tileProvider(mProvider));
    }

    private void sendEmail(){
        EditText mEmail = findViewById(R.id.enter_email);
        String emailAddress = mEmail.getText().toString();
        if (emailAddress!=""){
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{mEmail.getText().toString()});
            intent.putExtra(Intent.EXTRA_SUBJECT, "DIY GM Data");
            intent.putExtra(Intent.EXTRA_TEXT, "Data: \n"+detectorData);

            try{
                startActivity(Intent.createChooser(intent, "Send Mail"));
            }
            catch (android.content.ActivityNotFoundException ex){
                Toast.makeText(BluetoothMapActivity.this,
                        "There is no email client installed", Toast.LENGTH_SHORT);
            }
        }
        else{
            Toast.makeText(BluetoothMapActivity.this,
                    "Please enter a valid email address", Toast.LENGTH_SHORT);
        }
    }

    //Save Text File
    public void saveTextFile() {
        EditText mName = findViewById(R.id.enter_name);
        String sFileName = mName.getText().toString()+".txt";
        String sBody = "Data: \n"+detectorData;
        if (sFileName!=""){
            File root = new File(Environment.getExternalStorageDirectory()
                    .getAbsolutePath(), sFileName);
            try {
                FileOutputStream fos = new FileOutputStream(root);
                fos.write(sBody.getBytes());
                fos.close();

                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(this, "File Not Found", Toast.LENGTH_SHORT).show();
            }catch (IOException e){
                e.printStackTrace();
                Toast.makeText(this, "Error Saving File", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Please Enter a File Name", Toast.LENGTH_SHORT).show();
        }

    }

    //export popup menu
    public void showPopup(View v){
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.export_menu);
        popupMenu.show();
    }
    //What the popup menu does
    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch(item.getItemId()){
            case R.id.exportEmail:
                //Button Visibility changes
                Button btnExport = (Button) findViewById(R.id.btnExport);
                Button btnMark = (Button) findViewById(R.id.btnMark);

                LinearLayout getEmail = (LinearLayout) findViewById(R.id.getEmail);
                getEmail.setVisibility(View.VISIBLE);
                Button btnCancelEmail = (Button) findViewById(R.id.btnCancelEmail);
                btnCancelEmail.setVisibility(View.VISIBLE);
                btnExport.setVisibility(View.GONE);
                btnMark.setVisibility(View.VISIBLE);
                LinearLayout setTime = (LinearLayout) findViewById(R.id.setTime);
                setTime.setVisibility(View.GONE);
                TextView countRate = (TextView) findViewById(R.id.Count_Rate);
                TextView incomingMessages = (TextView) findViewById(R.id.incomingMessages);
                countRate.setVisibility(View.VISIBLE);
                incomingMessages.setVisibility(View.VISIBLE);

                Button btnDisableTimed = (Button) findViewById(R.id.btnDisableTimed);
                Button btnTimed = (Button) findViewById(R.id.btnTimed);
                btnTimed.setVisibility(View.VISIBLE);
                btnDisableTimed.setVisibility(View.GONE);

                mEmail = (EditText) findViewById(R.id.enter_email);
                mEmail.getText().clear();
                return true;

            case R.id.exportText:
                //Get permission to save
                if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        !=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1000);
                }
                else{
                    mSavePermissionGranted=true;
                }

                if (mSavePermissionGranted==true) {
                    //some reason it didn't like it unless I redid these with different names
                    Button btnExport2 = (Button) findViewById(R.id.btnExport);
                    Button btnMark2 = (Button) findViewById(R.id.btnMark);

                    LinearLayout getText = (LinearLayout) findViewById(R.id.getTextName);
                    getText.setVisibility(View.VISIBLE);
                    Button btnCancelText = (Button) findViewById(R.id.btnCancelText);
                    btnCancelText.setVisibility(View.VISIBLE);
                    btnExport2.setVisibility(View.GONE);
                    btnMark2.setVisibility(View.VISIBLE);
                    LinearLayout setTime2 = (LinearLayout) findViewById(R.id.setTime);
                    setTime2.setVisibility(View.GONE);
                    TextView countRate2 = (TextView) findViewById(R.id.Count_Rate);
                    TextView incomingMessages2 = (TextView) findViewById(R.id.incomingMessages);
                    countRate2.setVisibility(View.VISIBLE);
                    incomingMessages2.setVisibility(View.VISIBLE);
                    Button btnDisableTimed2 = (Button) findViewById(R.id.btnDisableTimed);
                    Button btnTimed2 = (Button) findViewById(R.id.btnTimed);
                    btnTimed2.setVisibility(View.VISIBLE);
                    btnDisableTimed2.setVisibility(View.GONE);

                    mName = (EditText) findViewById(R.id.enter_name);
                    mName.getText().clear();
                    return true;
                }else{
                    return true;
                }
            default:
                return false;
        }
    }
}
